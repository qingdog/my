create
    definer = root@localhost procedure tb_insert()
BEGIN
DECLARE i INT;
SET i = 0;
START TRANSACTION;
WHILE i < 10000000 DO -- 10即插入10条数据
        INSERT INTO tb_goods (`title`,`number`) VALUES (concat("手机",i),i);
        SET i = i+1;
END WHILE;
COMMIT;
END;

